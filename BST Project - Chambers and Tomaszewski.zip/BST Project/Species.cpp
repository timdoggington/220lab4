#include "Species.hpp"
// Made By Alexander Chambers and TJ Tomaszewski

#include <iostream>
#include <string>
using namespace std;

Species::Species(string s, string st, string inf) {
	name = s;
	status = st;
	info = inf;
}

Species::Species() {
	name = "";
	status = "";
	info = "";
}


